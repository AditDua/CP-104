"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import find_shortest
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


input_file_path = 'words.txt'


with open(input_file_path, 'r') as fh:

    shortest_word = find_shortest(fh)

print(f"File '{input_file_path}' open for reading")
print(f"'{shortest_word}' is the first shortest word")
