"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import file_copy_n
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


input_file_path = 'words.txt'
output_file_path = 'new_words.txt'


with open(input_file_path, 'r') as fh_1:

    with open(output_file_path, 'a') as fh_2:

        n = int(input('Number of lines to copy from fh_1 to fh_2: '))

        for _ in range(n):
            line = fh_1.readline()
            if not line:
                break
            fh_2.write(line)

print(f"Copying '{input_file_path}' to '{output_file_path}'")
print(f"Number of lines to copy: {n}")
