"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import customer_append
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


with open('customers.txt', 'a') as file_handle:

    data_to_append = ['35612', 'David', 'Brown', 237.56, '2008-10-10']

    customer_append(file_handle, data_to_append)

    print("Data:", data_to_append)
    print("data appended to file")
