"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-11"
-------------------------------------------------------
"""
# Imports
from functions import pay_raise
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Inputs
status = input("Please enter your status: ")
years = int(input("Please enter number of years: "))
salary = float(input('Please enter your salary: '))

new_salary = pay_raise(status, years, salary)
print(new_salary)
