"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-11"
-------------------------------------------------------
"""
# Imports
from functions import get_pay
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


hourly_rate = float(input('Enter the hourly rate: '))
hours_worked = float(input("Enter the hours worked: "))
net_payment = get_pay(hourly_rate, hours_worked)
print(net_payment)
