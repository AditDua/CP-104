"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-13"
-------------------------------------------------------
"""
# Imports
from functions import lawn_mow_time
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """

# Inputs


width = float(input("Width of a lawn in metres: "))
length = float(input("Length of a lawn in metres: "))
speed = float(input("Square metres cut per minute: "))

time = lawn_mow_time(width, length, speed)
print(time)
