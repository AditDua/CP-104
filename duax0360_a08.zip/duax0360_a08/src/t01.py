"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import add_spaces
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


sentence = str(input("Sentence that represents a sentence in which all the words are run together (no spaces), but the first character of each word uppercase. sentence has at least one character: "))
spaced = add_spaces(sentence)
print(f"add_spaces('{sentence}') -> {spaced}")
