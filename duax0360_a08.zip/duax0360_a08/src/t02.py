"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import pluralize
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


string = str(input('A string: '))
pluralized = pluralize(string)
print(f"pluralize('{string}') -> {pluralized}")
