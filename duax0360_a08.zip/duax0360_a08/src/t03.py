"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import common_end
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


str1 = str(input('First string for ending comparison: '))
str2 = str(input('Second string for ending comparison: '))
suffix = common_end(str1, str2)
print(f"common_end('{str1}','{str2}') -> {suffix}")
