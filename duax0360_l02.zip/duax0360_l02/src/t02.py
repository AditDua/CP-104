"""
-------------------------------------------------------
Lab 2, Task 2
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-17"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


WATER_FREEZING = 32
F_C_RATIO = 5/9

fahrenheit = int(input('Please enter the temperature (F):'))
celsius = (fahrenheit-WATER_FREEZING)*(F_C_RATIO)
print(f'Temperature (C): {celsius}')
