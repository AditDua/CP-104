"""
-------------------------------------------------------
Lab 2 ,Task 6
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-17"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


principal = float(input('Please enter your principal amount ($): '))
no_of_years = int(input('Please enter the number of years: '))
yearly_interest_rate = float(
    input('Please enter your yearly interest rate (%): '))
months = no_of_years*12
monthly_rate = (yearly_interest_rate/100)/12
monthly_payment = principal * \
    (monthly_rate*((1+monthly_rate)**months)/(((1+monthly_rate)**months)-1))
print(f'The monthly payments are: ${monthly_payment}')
