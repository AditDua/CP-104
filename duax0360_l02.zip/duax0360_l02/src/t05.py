"""
-------------------------------------------------------
Lab 2,Task 5
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-17"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


hourly_pay = float(input('Please enter your hourly rate of pay: $'))
hours_worked = float(input('Please enter the hours worked in a week: $'))
pay_for_the_week = hourly_pay*hours_worked
print(f'Total pay for the week: ${pay_for_the_week}')
