"""
-------------------------------------------------------
Lab 2, Task 9
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-17"
-------------------------------------------------------
"""
# Imports


# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


PI = 3.14

diameter = float(input('Please enter diameter of container base (cm): '))
height = float(input('Please enter height of container (cm): '))
cost = float(input('Please enter cost of material ($/cm^2): '))
no_of_containers = int(input('Please enter number of containers: '))
radius = diameter/2
area_circular_base = PI*radius**2
outside_area = 2*PI*radius*height
surface_area = area_circular_base+outside_area
cost_one = surface_area*cost
cost_all = cost_one*no_of_containers
print(f'The total cost of one containers is ${cost_one}')
print(f'The total cost of all containers is ${cost_all}')
