"""
-------------------------------------------------------
Lab 2, Task 12
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


SECONDS_PER_MINUTE = 60

seconds = int(input('Please enter number of seconds: '))
days = seconds/(24 * 3600)
seconds = seconds % (24*3600)
hours = seconds / 3600
seconds %= 3600
minutes = seconds/SECONDS_PER_MINUTE
seconds %= SECONDS_PER_MINUTE
seconds = seconds

print('Days:', int(days), 'Hours:', int(hours),
      'Minutes:', int(minutes), 'Seconds:', int(seconds))
