"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-08"
-------------------------------------------------------
"""
# Imports
from functions import symmetric_difference
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


user_input = input("A list : ")
input_list = user_input.split(',')
source1 = [float(item) for item in input_list]
user_input = input("A list: ")
input_list = user_input.split(',')
source2 = [float(item) for item in input_list]
target = symmetric_difference(source1, source2)
print(target)
