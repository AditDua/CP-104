"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


integer = 654321
decimal = 654.32
phrase = "Hello World"


print(f"Print integer as an integer: {integer:d}")
print(f"Print integer as a floating point value: {integer:.2f}")
#print(f"Print integer as a string: {integer:s}")
#print(f"Print decimal as an integer: {decimal:d}")
print(f"Print decimal as a floating point value: {decimal:.2f}")
#print(f"Print decimal as a string: {decimal:s}")
#print(f"Print phrase as a floating point value: {phrase:.2f}")
#print(f"Print phrase as an integer: {phrase:d}")
print(f"Print phrase as a string: {phrase:s}")
