"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


print('Selected quotes from Mark Twain:')
print()
print('"Do the right thing. It will gratify some people and astonish the rest."')
print('"All generalizations are false, including this one."')
print('"It is better to keep your mouth closed and let people think you are a fool')
print('than to open it and remove all doubt."')
