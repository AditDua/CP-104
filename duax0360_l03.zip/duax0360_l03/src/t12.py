"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


first = 100
second = 34
third = 933
total = first+second+third
print("Values")
print(f"First:  {first:_>6}")
print(f"Second: {second:_>6}")
print(f"Third:  {third:_>6}")
print(f"Total:  {total:_>6}")
