"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


sweatband_cost = float(input('Enter sweatband cost: $'))
pants_cost = float(input('Enter pants cost: $'))
jacket_cost = float(input('Enter jacket cost: $'))
total = jacket_cost+pants_cost+sweatband_cost


print("Clothes      Cost")
print(f"Sweatband    $ {sweatband_cost:>6.2f}")
print(f"Pants        $ {pants_cost:>6.2f}")
print(f"Jacket       $ {jacket_cost:>6.2f}")
print(f"Total        $ {total:>6.2f}")
