"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""
# Imports
from functions import find_word_horizontal, words_to_matrix
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


word_list = str(
    input('A list containing the words to be placed in the matrix:'))
word_list = word_list.split(',')
matrix = words_to_matrix(word_list)
word = str(input('A list of row indexes: '))
rows = find_word_horizontal(matrix, word)
print(rows)
