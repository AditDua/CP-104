"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
# Imports
from functions import time_split

# Inputs
initial_seconds = int(input('Time Elapsed: '))
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


days, hours, minutes, seconds = time_split(initial_seconds)
print(days, hours, minutes, seconds)
