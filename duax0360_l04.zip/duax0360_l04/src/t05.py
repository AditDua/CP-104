"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
# Imports
from functions import right_triangle
# Constants

# Inputs
adjacent = float(input('Adjacent: '))
opposite = float(input('Opposite: '))


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


hyp, per, area = right_triangle(adjacent, opposite)
print(hyp, per, area)
