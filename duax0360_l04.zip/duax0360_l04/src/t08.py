"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
# Imports
from functions import computer_costs

# Inputs
computer_cost = float(input('Cost per unit: $'))
computers_bought = int(input('Unit bought: '))
commission_percent = float(input('Commssion: '))

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


pre_commission_cost, total_cost = computer_costs(
    computer_cost, computers_bought, commission_percent)
print(pre_commission_cost, total_cost)
