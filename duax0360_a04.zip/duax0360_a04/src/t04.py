"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-26"
-------------------------------------------------------
"""
# Imports
from functions import colour_combine
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


rgb_colour1 = str(input('A primary RGB rgb_colour: '))
rgb_colour2 = str(input('A primary RGB rgb_colour: '))


rgb_colour = colour_combine(rgb_colour1, rgb_colour2)
print(rgb_colour)
