"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-01"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


input_date = int(input("Enter a date in YYYYMMDD format: "))
year = input_date // 10000
month = (input_date // 100) % 100
day = input_date % 100
print(f"The formatted date is: {year}/{month:02d}/{day:02d}")
