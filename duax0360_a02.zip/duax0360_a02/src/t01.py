"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


total_sales = float(input('Enter the total sales: '))
ANNUAL_TAX = 18.50
annual = ANNUAL_TAX/100
tax = total_sales*annual
line = '-'
print()
print('PROJECTED TAX REPORT')
print(f'{line:-^25}')
print(f"{'Total Sales:':13} $ {total_sales:.2f}")
print(f"{'Annual Tax:':13} % {ANNUAL_TAX:.2f}")
print(f'{line:-^25}')
print(f"{'Tax:':13} $ {tax:.2f}")
