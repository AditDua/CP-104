"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-01"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


num_flyers = int(input("Number of flyers: "))
num_people = int(input("Number of delivery people: "))

flyers_per_person = num_flyers//num_people
flyers_left = num_flyers % num_people
print(f"Flyers per delivery person: {flyers_per_person}")
print(f"Flyers left over: {flyers_left}")
