"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import interest_table
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


principal_amount = float(input("Original value of a loan: "))
interest_rate = float(input('Yearly interest interest_rate as a %: '))
payment = float(input('The monthly payment: '))
print(interest_table(principal_amount, interest_rate, payment))
