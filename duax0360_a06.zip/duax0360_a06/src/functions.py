"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


def total_wins():
    """
    -------------------------------------------------------
    Takes no parameters and prompts the user to enter a series
    of strings representing the output of a game until an empty
    string is entered. Counts and returns the occurrences of
    'purple' and 'gold' in the input.

    Use: result = total_wins()
    -------------------------------------------------------
    Returns:
        result - A tuple containing the count of 'purple' and
                 'gold' occurrences.
    """
    purple_count = 0
    gold_count = 0

    while True:
        user_input = input("Enter the winning team: ").lower()

        if user_input == '':
            break

        if user_input == 'purple':
            purple_count += 1
        elif user_input == 'gold':
            gold_count += 1

    return purple_count, gold_count


def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    prime = True

    if number <= 1:
        prime = False
    else:
        i = 2
        while i <= int(number ** 0.5):
            if number % i == 0:
                prime = False
                break
            i += 1

    return prime


def interest_table(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    print(f"Principal: ${principal_amount:,.2f}")
    print(f"Interest Rate: {interest_rate:.2f}%")
    print(f"Monthly Payment: ${payment:,.2f}")
    print("------------------------------------")
    print("Month   Interest   Payment   Balance")
    print("------------------------------------")

    # Initialize variables
    month = 1
    remaining_balance = principal_amount

    while remaining_balance > 0:
        monthly_interest = (interest_rate / 12 / 100) * remaining_balance
        actual_payment = min(payment, remaining_balance + monthly_interest)
        remaining_balance -= (actual_payment - monthly_interest)
        print(
            f"{month:>5}{monthly_interest:>11,.2f}{actual_payment:>10,.2f}{remaining_balance:>10,.2f}")
        month += 1

    return None


def count_of_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_of_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    ------------------------------------------------------
    """
    if number < 0:
        number = abs(number)

    digits = 0

    while number > 0:
        number //= 10
        digits += 1

    return digits


def factor_summation(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = factor_summation(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """
    total = 0

    factor = 1

    while factor <= number // 2:
        if number % factor == 0:
            total += factor
        factor += 1

    return total
