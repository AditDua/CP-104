"""
-------------------------------------------------------
Exam Task 2 Function Definitions
-------------------------------------------------------
Author: Adit Dua
ID:     169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-12-14"
-------------------------------------------------------
"""
# Constants
DRY_DAYS = 4
DAMP_DAYS = 8
WET_DAYS = 9

# Your constants here


def rainfall():
    """
    -------------------------------------------------------
    Asks the user for daily rainfall (in mm) from the keyboard.
    The function stops asking for rainfall when the user enters -1.
    The function returns:
        the total number of dry days (rainfall lower than 4mm)
        the total number of damp days (rainfall 4mm - 8mm)
        the total number of wet days (rainfall greater than 8mm)
        the average rainfall for all days (rounded down)
    Do all inputs and calculations in integer.
    Use: dry_days, damp_days, wet_days, avg = rainfall()
    -------------------------------------------------------
    Returns‌​‌​​​​‌​​‌‌‌‌​​‌‌‌‌​​​‌‌​​​:
        dry_days - number of dry days (int)
        damp_days - number of damp days (int)
        wet_days - number of wet days (int)
        avg - average rainfall of all days (int)
    -------------------------------------------------------
    """

    # your code here
    dry_days = 0
    damp_days = 0
    wet_days = 0
    total_rainfall = 0
    num_days = 0

    while True:
        rainfall = int(
            input("Enter the daily rainfall in mm (enter -1 to stop): "))
        if rainfall == -1:
            break
        if rainfall < DRY_DAYS:
            dry_days += 1
        elif DRY_DAYS <= rainfall <= DAMP_DAYS:
            damp_days += 1
        else:
            wet_days += 1
        total_rainfall += rainfall
        num_days += 1

    if num_days == 0:
        avg = 0
    else:
        avg = total_rainfall // num_days

    return dry_days, damp_days, wet_days, avg
