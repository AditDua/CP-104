"""
-------------------------------------------------------
Testing for Task 7: line_lengths
-------------------------------------------------------
Author: Adit Dua
ID:     169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-12-14"
-------------------------------------------------------
"""
# Imports
from t07_functions import line_lengths
# your imports here

# Your code here

with open('source.txt', 'r') as f_in:

    with open('short.txt', 'w') as f_short, open('long.txt', 'w') as f_long:
        short_lines, long_lines = line_lengths(f_in, f_short, f_long, 16)
        print("Number of short lines:", short_lines)
        print("Number of long lines:", long_lines)
