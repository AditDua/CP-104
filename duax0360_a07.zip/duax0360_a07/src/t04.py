"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-14"
-------------------------------------------------------
"""
# Imports
from functions import list_subtract, list_positives
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


minuend = list_positives()

# Ask the user for subtrahend1
subtrahend = list_positives()

print(f"list_subtract({minuend}, {subtrahend}) -> None")
list_subtract(minuend, subtrahend)
print(f" minuend after: {minuend}")
