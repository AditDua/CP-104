"""
-------------------------------------------------------
Midterm Trial
-------------------------------------------------------
Author: Adit Dua
ID:     169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2022-11-05"
-------------------------------------------------------
"""
print("Congratulations, you imported this project correctly.")


for i in range(5):
    print(f"{i:4d}", end="")
print()

integer = 1234
print(f"|{integer:9d}|")
