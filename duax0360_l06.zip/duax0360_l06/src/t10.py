"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-10-26"
-------------------------------------------------------
"""
# Imports
from functions import treadmill
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


burnt_per_minute = float(input('Calories burnt per minute: '))
start = int(input('Start time in minutes: '))
end = int(input('End time in minutes: '))
inc = int(input('Increment in minutes: '))
treadmill = treadmill(burnt_per_minute, start, end, inc)
print(treadmill)
