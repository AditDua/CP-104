"""
-------------------------------------------------------
Assignment 1 Task 3
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


miles = float(input('Length in miles: '))
CF = 1.61
kilometers = miles*CF
print(f'Length in km: {kilometers}')
