"""
-------------------------------------------------------
Assignment 1 Task 2
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


age = int(input('Please enter you age: '))
favourite_band = input('Please enter your favourite band: ')
print(f'I am {age} years old and {favourite_band} is my favourite band.')
