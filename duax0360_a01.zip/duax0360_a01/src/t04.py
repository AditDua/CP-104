"""
-------------------------------------------------------
Assignment 1 Task 4
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-16"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


cost_dosa = float(input('Cost of 1 dosa: $'))
no_of_dosa = int(input('Number of dosa: '))
total_cost = cost_dosa*no_of_dosa
print(f'Total cost of {no_of_dosa} dosas: ${total_cost}')
