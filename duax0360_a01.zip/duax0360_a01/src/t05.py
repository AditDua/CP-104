"""
-------------------------------------------------------
Assignment 1 Task 5
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-09-16"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


principal = float(input('Principle: $'))
interest = float(input('Interest (%): '))
no_of_years = int(input('Number of years: '))
no_of_times = int(input('Number of times interest compounded per year: '))
rate_of_interest = interest/100
amount = principal*(1+rate_of_interest/no_of_times)**(no_of_times*no_of_years)
print(f'Balance: ${amount}')
