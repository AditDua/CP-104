"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import file_statistics
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


file_name = input("Enter the file name: ")

# Open the file for reading
with open(file_name, 'r', encoding='utf-8') as file_handle:
    # Call the file_statistics function to get the statistics
    ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)

print(f'file_handle = open("{file_name}", "r", "utf-8")')
print()
print(
    f"file_statistics(file_handle) -> {ucount}, {lcount}, {dcount}, {wcount}, {rcount}")
print()
print('file_handle.close()')
