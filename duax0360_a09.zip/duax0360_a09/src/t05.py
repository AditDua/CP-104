"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import student_stats
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


file_name = input(
    "Student information file in the format surname,forename,id,mark: ")

# Open the file for reading
with open(file_name, "r", encoding="utf-8") as file_handle:
    # Call the student_stats function to get the statistics
    l_id, h_id, avg = student_stats(file_handle)


# Print the result
print(f"student_stats(file_handle) -> {l_id}, {h_id}, {avg}")
