"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import file_top
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


file_name = input("Enter the file name: ")

count = int(input("Enter the number of lines to print (int > 0): "))

print(f'file_handle = open("{file_name}", "r", "utf-8")')
print(f"file_top(file_handle,{count})")
print()
with open(file_name, "r", encoding="utf-8") as file_handle:
    file_top(file_handle, count)


print('file_handle.close()')
