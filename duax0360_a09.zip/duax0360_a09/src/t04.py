"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import line_numbering
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


input_file_name = input("Enter the input file name: ")


output_file_name = input("Enter the output file name: ")


with open(input_file_name, "r", encoding="utf-8") as fh_read, open(output_file_name, "w", encoding="utf-8") as fh_write:

    line_numbering(fh_read, fh_write)
