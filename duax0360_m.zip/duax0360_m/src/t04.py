"""
-------------------------------------------------------
Midterm A Task 4 Testing
-------------------------------------------------------
Author: Adit Dua
ID:     169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Imports

# your imports here
from t04_functions import result
# your code here
response = str(input('A response to classify: '))
classification = result(response)
print(f"result({response}) -> {classification}")
