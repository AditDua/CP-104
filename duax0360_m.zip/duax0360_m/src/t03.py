"""
-------------------------------------------------------
Midterm A Task 3 Testing
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
# Imports
from t03_functions import servicing

cost = servicing()
print(f"Cost: ${cost:.2f}")
